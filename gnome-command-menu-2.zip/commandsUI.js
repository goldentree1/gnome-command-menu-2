/* commandsUI.js 
 *
 * This file is part of the Custom Command Menu GNOME Shell extension
 * https://github.com/StorageB/custom-command-menu
 * 
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

import { gettext as _ } from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';
import Adw from 'gi://Adw';
import Gtk from 'gi://Gtk';
import Gdk from 'gi://Gdk';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';

let draggedRow = null;

export default class commandsUI extends Adw.PreferencesPage {
    static {
        GObject.registerClass({
            GTypeName: 'commandsUI',
        }, this);
    }

    _init(params = {}) {
        const { menus, menuIdx, settings, ...args } = params;
        super._init(args);
        this.menuIdx = menuIdx;
        this.menus = menus;
        // const menu = this.menus[this.menuIdx];

        const style = new Gtk.CssProvider();
        const cssData = `button > label { font-weight: normal; }`;
        style.load_from_data(cssData, cssData.length);
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(),
            style,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        );

        const mainGroup = new Adw.PreferencesGroup();

        // // menu picker + add/remove buttons
        // const menuPickerBox = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 12 });
        // const addMenuButton = new Gtk.Button({ label: _('Add Menu') });
        // const removeMenuButton = new Gtk.Button({ label: _('Remove Menu') });
        // const menuSelector = new Gtk.ComboBoxText();
        // menuSelector.append_text('Main Menu');
        // menuSelector.set_active(0);
        // menuPickerBox.append(menuSelector);
        // menuPickerBox.append(addMenuButton);
        // menuPickerBox.append(removeMenuButton);
        // mainGroup.add(menuPickerBox);

        // // menu metadata editor
        // const metadataGroup = new Adw.PreferencesGroup({ title: _('Menu Metadata') });
        // const metadataBox = new Gtk.Box({ orientation: Gtk.Orientation.VERTICAL, spacing: 12 });

        // const titleRow = new Adw.EntryRow({ title: _('Title'), text: menu.title || '' });
        // const iconRow = new Adw.EntryRow({ title: _('Icon'), text: menu.icon || '' });
        // const browseIconButton = new Gtk.Button({ label: _('Browse…') });
        // const viewIconsButton = new Gtk.Button({ label: _('System Icons…') });
        // const iconButtonBox = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 6 });
        // iconButtonBox.append(browseIconButton);
        // iconButtonBox.append(viewIconsButton);

        // const iconContainer = new Gtk.Box({ orientation: Gtk.Orientation.VERTICAL });
        // iconContainer.append(iconRow);
        // iconContainer.append(iconButtonBox);

        // const positionRow = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 6 });
        // const leftToggle = Gtk.ToggleButton.new_with_label(_('Left'));
        // const centerToggle = Gtk.ToggleButton.new_with_label(_('Center'));
        // const rightToggle = Gtk.ToggleButton.new_with_label(_('Right'));
        // positionRow.append(leftToggle);
        // positionRow.append(centerToggle);
        // positionRow.append(rightToggle);

        // const indexRow = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 6 });
        // const indexEntry = new Adw.EntryRow({ title: _('Index'), text: typeof menu.index === 'number' ? String(menu.index) : '' });
        // const autoIndexButton = Gtk.ToggleButton.new_with_label(_('Auto'));
        // indexRow.append(indexEntry);
        // indexRow.append(autoIndexButton);

        // metadataBox.append(titleRow);
        // metadataBox.append(iconContainer);
        // metadataBox.append(positionRow);
        // metadataBox.append(indexRow);
        // metadataGroup.add(metadataBox);

        // commands editor listbox
        this.commandsListBox = new Gtk.ListBox();
        this.commandsListBox.add_css_class('boxed-list');
        const scroller = new Gtk.ScrolledWindow();
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC);
        scroller.set_propagate_natural_height(true);
        scroller.set_child(this.commandsListBox);
        const overlay = new Adw.ToastOverlay();
        overlay.set_child(new Adw.Clamp({ child: scroller }));
        const commandEditorGroup = new Adw.PreferencesGroup();
        const box = new Gtk.Box({ orientation: Gtk.Orientation.VERTICAL });
        box.append(overlay);

        const dropTarget = Gtk.DropTarget.new(Gtk.ListBoxRow, Gdk.DragAction.MOVE);
        dropTarget.connect('drop', (_target, value, _x, y) => this._onRowDropped(value, y));
        this.commandsListBox.add_controller(dropTarget);

        this._scroller = scroller;

        // buttons
        const refreshButton = new Gtk.Button();
        refreshButton.set_child(Gtk.Image.new_from_icon_name('view-refresh-symbolic'));
        refreshButton.set_tooltip_text(_('Refresh Extension'));
        refreshButton.connect('clicked', () => {
            settings.set_int('restart-counter', settings.get_int('restart-counter') + 1);
        });

        const newButton = new Gtk.Button();
        newButton.set_child(Gtk.Image.new_from_icon_name('document-new-symbolic'));
        newButton.set_tooltip_text(_('New (raw save)'));
        newButton.connect('clicked', () => {
            try {
                const json = JSON.stringify(this.menu, null, 2);
                const filePath = GLib.build_filenamev([GLib.get_home_dir(), '.commands.json']);
                GLib.file_set_contents(filePath, json, -1);
                print('Commands saved to ~/.commands.json');
            } catch (e) {
                logError(e, 'Failed to save commands');
            }
        });

        const saveButton = new Gtk.Button();
        saveButton.set_child(Gtk.Image.new_from_icon_name('document-save-symbolic'));
        saveButton.set_tooltip_text(_('Save and Reload'));
        saveButton.connect('clicked', () => {
            log("[CMDMENU_PREFS]", "clicked save!");

            const newMenu = [];
            const stack = [{ depth: -1, items: newMenu }];

            let row = this.commandsListBox.get_first_child();
            while (row) {
                const item = row._item;
                const depth = row._depth || 0;
                log('[CMDMENU_PREFS]', item);

                const newItem = {
                    type: item.type,
                    title: item.title || '',
                    icon: item.icon || undefined,
                    command: item.command || '',
                };

                // Handle nested submenu logic
                while (stack.length > 1 && depth <= stack[stack.length - 1].depth) {
                    stack.pop();
                }

                // Add to current parent's items array
                stack[stack.length - 1].items.push(newItem);

                // If this is a submenu, push to stack for following items
                if (item.type === 'submenu') {
                    newItem.submenu = [];
                    stack.push({ depth, items: newItem.submenu });
                }

                row = row.get_next_sibling();
            }

            this.menus[this.menuIdx].menu = newMenu;

            try {
                const json = JSON.stringify(this.menus, null, 2);
                const filePath = GLib.build_filenamev([GLib.get_home_dir(), '.commands.json']);
                GLib.file_set_contents(filePath, json, -1);
                settings.set_int('restart-counter', settings.get_int('restart-counter') + 1);
            } catch (e) {
                logError(e, 'Failed to save commands');
            }
        });

        const buttonBox = new Gtk.Box({
            margin_top: 12,
            margin_bottom: 12,
            orientation: Gtk.Orientation.HORIZONTAL,
            homogeneous: true,
            spacing: 12,
        });

        [newButton, saveButton, refreshButton].forEach(button => {
            button.set_hexpand(true);
            button.set_halign(Gtk.Align.FILL);
            buttonBox.append(button);
        });

        commandEditorGroup.add(buttonBox);
        commandEditorGroup.add(box);

        this.add(mainGroup);
        // this.add(metadataGroup);
        this.add(commandEditorGroup);

        this.populateCommandsListBox(this.commandsListBox, 0, this.menus[this.menuIdx].menu);
    }

    populateCommandsListBox(listBox, depth, items) {
        if (!Array.isArray(items)) return;
        for (const item of items) {
            let row;
            if (item.type === 'separator') {
                row = new Adw.ExpanderRow({
                    title: `<b>${_('Separator')}</b>`,
                    use_markup: true,
                    selectable: false,
                    expanded: false,
                    margin_start: depth * 24,
                });
            } else if (item.type === 'label') {
                row = new Adw.ExpanderRow({
                    title: `<b>Label:</b> ${item.title || ''}`,
                    use_markup: true,
                    selectable: false,
                    expanded: false,
                    margin_start: depth * 24,
                });

                const entryRowTitle = new Adw.EntryRow({ title: _('Title:'), text: item.title || '' });

                entryRowTitle.connect('notify::text', () => {
                    item.title = entryRowTitle.text;
                    row.set_title(`<b>Label:</b> ${item.title || ''}`);
                });

                row.add_row(entryRowTitle);
            } else if (item.type === "submenu") {
                row = new Adw.ExpanderRow({
                    title: `<b>Submenu:</b> ${item.title || ''}`,
                    selectable: false,
                    expanded: false,
                    margin_start: depth * 24,
                });
                const entryRowTitle = new Adw.EntryRow({ title: _('Title:'), text: item.title || '' });

                entryRowTitle.connect('notify::text', () => {
                    item.title = entryRowTitle.text;
                    row.set_title(`<b>Submenu:</b> ${item.title || ''}`);
                });

                const entryRowIcon = new Adw.EntryRow({ title: _('Icon:'), text: item.icon || '' });
                entryRowIcon.connect('notify::text', () => {
                    item.icon = entryRowIcon.text;
                });

                row.add_row(entryRowTitle);
                row.add_row(entryRowIcon);
            } else if (item.command) {
                row = new Adw.ExpanderRow({
                    title: item.title || _('Untitled'),
                    selectable: false,
                    expanded: false,
                    margin_start: depth * 24,
                });

                const entryRowName = new Adw.EntryRow({ title: _('Name:'), text: item.title || '' });
                const entryRowCommand = new Adw.EntryRow({ title: _('Command:'), text: item.command || '' });
                const entryRowIcon = new Adw.EntryRow({ title: _('Icon:'), text: item.icon || '' });

                entryRowName.connect('notify::text', () => {
                    item.title = entryRowName.text;
                    row.set_title(item.title || _('Untitled'));
                });

                entryRowCommand.connect('notify::text', () => {
                    item.command = entryRowCommand.text;
                });

                entryRowIcon.connect('notify::text', () => {
                    item.icon = entryRowIcon.text;
                });

                row.add_row(entryRowName);
                row.add_row(entryRowCommand);
                row.add_row(entryRowIcon);
            }

            row._item = item;
            row._depth = depth;

            row.add_prefix(new Gtk.Image({
                icon_name: 'list-drag-handle-symbolic',
                css_classes: ['dim-label'],
            }));

            const dragSource = new Gtk.DragSource({ actions: Gdk.DragAction.MOVE });
            row.add_controller(dragSource);

            dragSource.connect('prepare', (_source, x, y) => {
                const value = new GObject.Value();
                value.init(Gtk.ListBoxRow);
                value.set_object(row);
                draggedRow = row;
                return Gdk.ContentProvider.new_for_value(value);
            });

            dragSource.connect('drag-begin', (_source, drag) => {
                const dragWidget = new Gtk.ListBox();
                dragWidget.set_size_request(row.get_width(), row.get_height());
                dragWidget.add_css_class('boxed-list');
                const dragRow = new Adw.ExpanderRow({
                    title: row.title,
                    selectable: false,
                });
                dragRow.add_prefix(new Gtk.Image({
                    icon_name: 'list-drag-handle-symbolic',
                    css_classes: ['dim-label'],
                }));
                dragWidget.append(dragRow);
                dragWidget.drag_highlight_row(dragRow);
                const icon = Gtk.DragIcon.get_for_drag(drag);
                icon.child = dragWidget;
                drag.set_hotspot(0, 0);
            });

            if (item.icon) {
                let iconWidget;
                if (item.icon.includes('/') || item.icon.includes('.')) {
                    iconWidget = Gtk.Image.new_from_file(item.icon);
                } else {
                    iconWidget = Gtk.Image.new_from_icon_name(item.icon);
                }
                iconWidget.add_css_class('dim-label');
                row.add_prefix(iconWidget);
            }

            listBox.append(row);

            if (item.type === "submenu") {
                this.populateCommandsListBox(listBox, depth + 1, item.submenu);
            }
        }
    }

    _onRowDropped(value, y) {
        const targetRow = this.commandsListBox.get_row_at_y(y);
        if (!value || !targetRow || !draggedRow) return false;
        if (targetRow === draggedRow) return false;

        const allRows = [...this.commandsListBox];
        const fromIndex = allRows.indexOf(draggedRow);
        const toIndex = allRows.indexOf(targetRow);
        if (fromIndex === -1 || toIndex === -1 || fromIndex === toIndex) return false;

        const getSubtreeBlock = (startIndex, all) => {
            const block = [all[startIndex]];
            const baseDepth = all[startIndex]._depth;
            for (let i = startIndex + 1; i < all.length; i++) {
                if (all[i]._depth > baseDepth) {
                    block.push(all[i]);
                } else {
                    break;
                }
            }
            return block;
        };

        const setRowDepth = (row, depth) => {
            row._depth = depth;
            row.set_margin_start(depth * 24);
        };

        const draggedBlock = getSubtreeBlock(fromIndex, allRows);
        const draggedDepth = draggedRow._depth;
        const blockLength = draggedBlock.length;

        // Prevent moving into own children
        if (toIndex > fromIndex && toIndex < fromIndex + blockLength) return false;

        // Determine new depth
        let newDepth = targetRow._depth;
        // if (targetRow._item?.type === 'submenu') newDepth += 1; // I REMOVED THIS - UNDESIRED BEHAVIOUR

        // Remove block
        for (const row of draggedBlock) this.commandsListBox.remove(row);

        let insertIndex = toIndex > fromIndex ? toIndex - blockLength : toIndex;

        // Adjust depth + reinsert
        for (const row of draggedBlock) {
            const relative = row._depth - draggedDepth;
            setRowDepth(row, newDepth + relative);
            this.commandsListBox.insert(row, insertIndex++);
        }

        // Scroll restoration
        const adjustment = this._scroller.get_vadjustment();
        const scrollValue = adjustment.get_value();

        GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
            adjustment.set_value(scrollValue);
            return GLib.SOURCE_REMOVE;
        });

        const clock = this._scroller.get_frame_clock?.();
        if (clock) {
            const handlerId = clock.connect('after-paint', () => {
                adjustment.set_value(scrollValue);
                clock.disconnect(handlerId);
            });
        }

        draggedRow = null;
        return true;
    }

}
